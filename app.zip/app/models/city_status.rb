class CityStatus < ApplicationRecord
	has_one :city
end
